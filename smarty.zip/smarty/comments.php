<?php

smarty_get_layout_file('/parts', '/comments');