<?php
/*
Template Name: Page 404
*/

smarty_get_layout_file('/parts', '/page-error');