<?php

smarty_get_layout_file('/parts/archives/events', '/single-stm_event');