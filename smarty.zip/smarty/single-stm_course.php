<?php

smarty_get_layout_file('/parts', '/archives/course/single-stm_course');