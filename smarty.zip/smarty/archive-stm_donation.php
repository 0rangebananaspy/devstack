<?php

smarty_get_layout_file( '/parts', '/archives/donation/archive-stm_donation' );