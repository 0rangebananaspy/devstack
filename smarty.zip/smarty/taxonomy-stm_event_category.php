<?php

smarty_get_layout_file( '/parts', '/archives/events/taxonomy-stm_event_category' );