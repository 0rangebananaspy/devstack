<?php

smarty_get_layout_file( '/parts', '/archives/events/archive-stm_event' );